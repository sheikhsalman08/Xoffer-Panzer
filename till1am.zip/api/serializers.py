from rest_framework import serializers
from offer.models import Offer
# from rest_framework_mongoengine.serializers import DocumentSerializer

# class OfferSerializer(DocumentSerializer):
# 	class Meta:
# 		model = Offer
# 		fields = '__all__'